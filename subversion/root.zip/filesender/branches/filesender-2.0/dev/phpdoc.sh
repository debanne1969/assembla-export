phpdoc -d "classes,includes,language,scripts,templates,www" -t dev/doc/phpdoc
