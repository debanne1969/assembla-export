<p>
    {cfg:site_name} est une installation de FileSender (<a rel="nofollow" href="http://www.filesender.org/" target="_blank">www.filesender.org</a>),
    développé pour les besoins de la communauté de l'éducation supérieure et de la recherche.
</p>
