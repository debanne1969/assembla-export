subject: Un invité a commencé à déposer des fichiers

{alternative:plain}

Madame, Monsieur,

Votre invité {guest.email} a commencé à déposer des fichiers.

Cordialement,
{cfg:site_name}

{alternative:html}

<p>
    Madame, Monsieur,
</p>

<p>
    Votre invité {guest.email} a commencé à déposer des fichiers.
</p>

<p>
    Cordialement,<br />
    {cfg:site_name}
</p>
