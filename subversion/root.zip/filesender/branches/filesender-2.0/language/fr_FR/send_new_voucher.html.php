<p>
    Une invitation permet à une personne quelconque de vous envoyer un fichier.
    Pour créer une invitation, entrez une adresse email et cliquez "Envoyer l'invitation".
    <br />
    Un e-mail sera envoyée à la personne avec un lien sur l'invitation.
</p>
