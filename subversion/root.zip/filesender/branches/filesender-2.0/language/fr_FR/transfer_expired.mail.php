subject: Fichiers expirés
subject: (fichiers expirés) {transfer.subject}

{alternative:plain}

Madame, Monsieur,

Le dépôt n°{transfer.id} sur {cfg:site_name} a expiré, ses fichiers ne sont donc plus disponibles au téléchargement.

Cordialement,
{cfg:site_name}

{alternative:html}

<p>
    Madame, Monsieur,
</p>

<p>
    Le dépôt n°{transfer.id} sur <a href="{cfg:site_url}">{cfg:site_name}</a> a expiré, ses fichiers ne sont donc plus disponibles au téléchargement.
</p>

<p>
    Cordialement,<br />
    {cfg:site_name}
</p>
