<p>
    Vous avez été déconnecté, merci d'avoir utilisé {cfg:site_name}.
</p>
