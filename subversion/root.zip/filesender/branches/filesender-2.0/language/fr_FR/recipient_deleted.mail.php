subject: Permission de télécharger révoquée

{alternative:plain}

Madame, Monsieur,

Votre droit à télécharger les fichiers du dépôt n°{transfer.id} a été révoquée.

Cordialement,
{cfg:site_name}

{alternative:html}

<p>
    Madame, Monsieur,
</p>

<p>
    Votre droit à télécharger les fichiers du dépôt n°{transfer.id} a été révoquée.
</p>

<p>
    Cordialement,<br />
    {cfg:site_name}
</p>
