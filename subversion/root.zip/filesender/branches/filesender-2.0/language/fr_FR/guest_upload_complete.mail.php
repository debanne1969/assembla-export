subject: Un invité a fini de déposer des fichiers

{alternative:plain}

Madame, Monsieur,

Votre invité {guest.email} a fini de déposer des fichiers.

Cordialement,
{cfg:site_name}

{alternative:html}

<p>
    Madame, Monsieur,
</p>

<p>
    Votre invité {guest.email} a fini de déposer des fichiers.
</p>

<p>
    Cordialement,<br />
    {cfg:site_name}
</p>
