<h1>Bienvenu sur {cfg:site_name}</h1>

<p>
    {cfg:site_name} propose un moyen sécurisé pour partager des gros fichiers avec tout le monde !
    Connectez-vous pour envoyer vos fichiers ou pour inviter vos interlocuteurs à vous en envoyer.
</p>
