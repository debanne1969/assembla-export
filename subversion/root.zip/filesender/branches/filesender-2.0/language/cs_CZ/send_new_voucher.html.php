Pomocí pozvánky Vám může jiná osoba zaslat soubor.<br />
Pro vytvoření pozvánky vložte emailovou adresu a vyberte Odeslat pozvánku.<br />
Email s odkazem na pozvánku bude odeslán příjemci.