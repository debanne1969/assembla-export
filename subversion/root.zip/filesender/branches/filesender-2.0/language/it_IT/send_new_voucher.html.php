Un voucher consente a un\'altra persona di inviarti un file.<br />
Per creare un voucher, inserisci un indirizzo email e seleziona <b>Invia voucher</b>.<br />
Il destinatario riceverà un\'email contenente il link per utilizzare il voucher.