subject: Report about {target.type} #{target.id}

{alternative:plain}

Dear Sir or Madam,

Please find the report about transfer #{target.id} attached to this email.

Best regards,
{cfg:site_name}

{alternative:html}

<p>
    Dear Sir or Madam,
</p>

<p>
    Please find the report about transfer #{target.id} attached to this email.
</p>

<p>Best regards,<br/>
{cfg:site_name}</p>
