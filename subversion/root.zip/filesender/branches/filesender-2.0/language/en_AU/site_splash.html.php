<h1>Welcome to {cfg:site_name}</h1>

<p>
    {cfg:site_name} is a secure way to share large files with anyone !
    Logon to upload your files or invite people to send you a file.
</p>
