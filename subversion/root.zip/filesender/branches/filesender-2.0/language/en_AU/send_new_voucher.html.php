A Voucher allows someone to send you a file.<br />
To create a voucher, enter an email address then select Send Voucher.<br />
An email will be sent to the recipient with a link to use the Voucher.
