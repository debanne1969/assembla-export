subject: translate email footer, shared by all languages

{alternative:plain}

Translate this email : {raw:translatableemail.link}

{alternative:html}

<p>
    Translate this email : <a href="{translatableemail.link}">{translatableemail.link}</a>
</p>
