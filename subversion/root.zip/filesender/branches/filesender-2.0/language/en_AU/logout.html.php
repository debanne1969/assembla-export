<p>
    Logout complete, thanks for using {cfg:site_name}.
</p>
