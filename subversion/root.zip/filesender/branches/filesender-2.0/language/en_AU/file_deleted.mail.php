subject: File no longer available for download

{alternative:plain}

Dear Sir or Madam,

The file {file.name} ({size:file.size}) has been deleted from transfer n°{transfer.id} and is no longer available for download.

Best regards,
{cfg:site_name}

{alternative:html}

<p>
    Dear Sir or Madam,
</p>

<p>
    The file {file.name} ({size:file.size}) has been deleted from transfer n°{transfer.id} and is no longer available for download.
</p>

<p>
    Best regards,<br />
    {cfg:site_name}
</p>
