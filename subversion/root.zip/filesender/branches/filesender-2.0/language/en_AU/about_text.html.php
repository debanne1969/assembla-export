<p>
    {cfg:site_name} is an installation of FileSender (<a rel="nofollow" href="http://www.filesender.org/" target="_blank">www.filesender.org</a>),
    which is developed to the requirements of the higher education and research community.
</p>
