subject: Download permission removed

{alternative:plain}

Dear Sir or Madam,

Your permission to download files from transfer n°{transfer.id} has been removed.

Best regards,
{cfg:site_name}

{alternative:html}

<p>
    Dear Sir or Madam,
</p>

<p>
    Your permission to download files from transfer n°{transfer.id} has been removed.
</p>

<p>
    Best regards,<br />
    {cfg:site_name}
</p>
