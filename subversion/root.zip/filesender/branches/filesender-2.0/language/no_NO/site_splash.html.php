Velkommen til {cfg:site_name}

{cfg:site_name} tilbyr en sikker og enkel måte for å sende store filer til alle dine samarbeidspartnere!  Logg på for å overføre filer eller for å invitere andre til å sende deg en fil.