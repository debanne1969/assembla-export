Con las \"Invitaciones de env&iacute;o\", cualquiera puede enviale un archivo.<br />
Para generar una \"Invitaci&oacute;n de env&iacute;o\", escriba una direcci&oacute;n de correo y pulse en \"Enviar la Invitaci&oacute;n\".<br />
El destinatario recibir&aacute; un correo con un enlace a la Invitaci&oacute;n.