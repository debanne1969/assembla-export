A meghívó lehetővé teszi, hogy valaki fájlt küldjön Önnek.<br />
Meghívó készítéséhez írja be a meghívni kívánt személy email címét, majd válassza a meghívó küldését.<br />
A meghívó emailben elküldésre kerül egy link amit a meghívott használhat.