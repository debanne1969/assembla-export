Ein Voucher erlaubt es einem Anderen, Ihnen eine Datei zu schicken.<br />
Um einen Voucher zu erstellen, geben Sie seine Email Adresse ein und klicken sie auf \'Voucher senden\'.<br />
Dem Empfänger wird eine E-Mail mit einem Link zum Voucher erhalten.