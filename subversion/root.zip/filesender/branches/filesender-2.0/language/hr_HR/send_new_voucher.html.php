Kupon omogućuje osobi da pošalje datoteku.<br />
Da stvorite kupon, unesite email adresu i pritisnite Pošalji kupon.<br />
Email će biti poslan primatelju sa vezom do kupona.