Vavčer uporabniku dovoljuje pošiljanje doumenta.<br />
Za ustvarjanje vavčerja vpišite elektronski naslov naslovnika, nato kliknite na gumb Pošlji vavčer.<br />
Naslovniku bo poslano sporočilo, s povezavo do vavčerja.