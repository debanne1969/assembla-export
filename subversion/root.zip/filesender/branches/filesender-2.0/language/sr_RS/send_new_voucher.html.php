Vaučer omogućuje osobi da pošalje fajl.<br />
Da bi napravili vaučer, unesite email adresu i kliknite na Pošalji vaučer.<br />
Email sa vezom do vaučera će biti poslan primaocu.