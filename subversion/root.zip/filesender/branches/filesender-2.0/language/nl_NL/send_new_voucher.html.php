Met een Uitnodiging kunt u iemand een bestand laten sturen.<br />
Om een Uitnodiging te maken, voer een e-mailadres in en klik op Stuur Uitnodiging.<br />
Er wordt dan een e-mail verstuurd naar de ontvanger met daarin een link om de uitnodiging te gebruiken.