<div class="error message">
    <?php echo $error ?>
</div>
