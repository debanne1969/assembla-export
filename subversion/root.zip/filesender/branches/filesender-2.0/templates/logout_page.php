<div class="box">
    {tr:logout}
</div>
