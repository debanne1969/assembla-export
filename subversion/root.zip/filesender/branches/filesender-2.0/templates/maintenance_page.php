<div class="box">
    <h2>{tr:undergoing_maintenance}</h2>
</div>
