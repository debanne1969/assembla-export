Compile filesenderup.mxml into www/swf/filesenderup.swf

Recommended Command Line  
"D:\Program Files\Adobe\Adobe Flash Builder 4\sdks\4.0.0\bin\mxmlc" -output www/swf/filesenderup.swf flex/src/filesenderup.mxml  -theme="D:\Program Files\Adobe\Adobe Flash Builder 4\sdks\4.0.0\frameworks\themes\Halo\halo.swc" -compatibility-version=3.0 -static-link-runtime-shared-libraries=true 
