<?php



if(!empty($this->data['htmlinject']['htmlContentPost'])) {
	foreach($this->data['htmlinject']['htmlContentPost'] AS $c) {
		echo $c;
	}
}


?>



		
		<br style="clear: right" />
	
	</div><!-- #content -->

</div><!-- #wrap -->

</body>
</html>
