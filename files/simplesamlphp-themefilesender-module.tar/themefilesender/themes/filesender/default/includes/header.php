<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php

/* Customised header.php based on templates/includes/header.php
   This page checks the SimpleSAMLphp version before displaying
   the language bar (uses the 1.7 languages if the version is 1.7.0 
   or higher, else it uses the 1.6 language names).
*/

/**
 * Support the htmlinject hook, which allows modules to change header, pre and post body on all pages.
 */
$this->data['htmlinject'] = array(
	'htmlContentPre' => array(),
	'htmlContentPost' => array(),
	'htmlContentHead' => array(),
);


$jquery = array();
if (array_key_exists('jquery', $this->data)) $jquery = $this->data['jquery'];

if (array_key_exists('pageid', $this->data)) {
	$hookinfo = array(
		'pre' => &$this->data['htmlinject']['htmlContentPre'], 
		'post' => &$this->data['htmlinject']['htmlContentPost'], 
		'head' => &$this->data['htmlinject']['htmlContentHead'], 
		'jquery' => &$jquery, 
		'page' => $this->data['pageid']
	);
		
	SimpleSAML_Module::callHooks('htmlinject', $hookinfo);	
}
// - o - o - o - o - o - o - o - o - o - o - o - o -




?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<script type="text/javascript" src="/<?php echo $this->data['baseurlpath']; ?>resources/script.js"></script>
<title><?php
if(array_key_exists('header', $this->data)) {
	echo $this->data['header'];
} else {
	echo 'simpleSAMLphp';
}
?></title>

	<link rel="stylesheet" type="text/css" href="/<?php echo $this->data['baseurlpath']; ?>resources/default.css" />
	<link rel="icon" type="image/icon" href="/<?php echo $this->data['baseurlpath']; ?>resources/icons/favicon.ico" />

	<!-- Use FileSender stylesheet/styles -->
	<style type="text/css"> #wrap { border: 0px; } </style>
	<link rel="stylesheet" type="text/css" href="/filesender/css/default.css" />
	<style type="text/css"> input, textarea { width: auto; } </style>
	<!-- End use FileSender stylesheet/styles -->


<?php

if(!empty($jquery)) {
	$version = '1.5';
	if (array_key_exists('version', $jquery))
		$version = $jquery['version'];
		
	if ($version == '1.5') {
		if (isset($jquery['core']) && $jquery['core'])
			echo('<script type="text/javascript" src="/' . $this->data['baseurlpath'] . 'resources/jquery.js"></script>' . "\n");
	
		if (isset($jquery['ui']) && $jquery['ui'])
			echo('<script type="text/javascript" src="/' . $this->data['baseurlpath'] . 'resources/jquery-ui.js"></script>' . "\n");
	
		if (isset($jquery['css']) && $jquery['css'])
			echo('<link rel="stylesheet" media="screen" type="text/css" href="/' . $this->data['baseurlpath'] . 
				'resources/uitheme/jquery-ui-themeroller.css" />' . "\n");	
			
	} else if ($version == '1.6') {
		if (isset($jquery['core']) && $jquery['core'])
			echo('<script type="text/javascript" src="/' . $this->data['baseurlpath'] . 'resources/jquery-16.js"></script>' . "\n");
	
		if (isset($jquery['ui']) && $jquery['ui'])
			echo('<script type="text/javascript" src="/' . $this->data['baseurlpath'] . 'resources/jquery-ui-16.js"></script>' . "\n");
	
		if (isset($jquery['css']) && $jquery['css'])
			echo('<link rel="stylesheet" media="screen" type="text/css" href="/' . $this->data['baseurlpath'] . 
				'resources/uitheme16/ui.all.css" />' . "\n");	
	}
}

if(!empty($this->data['htmlinject']['htmlContentHead'])) {
	foreach($this->data['htmlinject']['htmlContentHead'] AS $c) {
		echo $c;
	}
}




?>

	
	<meta name="robots" content="noindex, nofollow" />
	

<?php	
if(array_key_exists('head', $this->data)) {
	echo '<!-- head -->' . $this->data['head'] . '<!-- /head -->';
}
?>
</head>
<?php
$onLoad = '';
if(array_key_exists('autofocus', $this->data)) {
	$onLoad .= 'SimpleSAML_focus(\'' . $this->data['autofocus'] . '\');';
}
if (isset($this->data['onLoad'])) {
	$onLoad .= $this->data['onLoad']; 
}

if($onLoad !== '') {
	$onLoad = ' onload="' . $onLoad . '"';
}
?>
<body<?php echo $onLoad; ?>>

<div id="wrap">
	
	<div id="header">
		<!-- Use FileSender banner -->
		<img src="/filesender/displayimage.php" width="800" height="60" border="0" alt="banner"/>
		<!-- End use FileSender banner -->
		<h1><a style="text-decoration: none; color: white" href="/<?php echo $this->data['baseurlpath']; ?>"><?php 
			echo (isset($this->data['header']) ? $this->data['header'] : 'simpleSAMLphp'); 
		?></a></h1>
	</div>

	
	<?php 
	
	$includeLanguageBar = TRUE;
	if (!empty($_POST)) 
		$includeLanguageBar = FALSE;
	if (isset($this->data['hideLanguageBar']) && $this->data['hideLanguageBar'] === TRUE) 
		$includeLanguageBar = FALSE;
	
	if ($includeLanguageBar) {
		
		
		echo '<div id="languagebar">';
		$languages = $this->getLanguageList();
		
		/* SimpleSAMLphp 1.7.0+ uses a different list of language names. So
		 * check the version and use the appropriate definitions.
		 */
		if(!array_key_exists('version', $this->data)) {
			$config = SimpleSAML_Configuration::getInstance();
			$this->data['version'] = $config->getVersion();
		}
		if (version_compare($this->data['version'], '1.7.0', '>=')) {
			$langnames = array(
					'no' => 'Bokmål',
					'nn' => 'Nynorsk',
					'se' => 'Sámegiella',
					'sam' => 'Åarjelh-saemien giele',
					'da' => 'Dansk',
					'en' => 'English',
					'de' => 'Deutsch',
					'sv' => 'Svenska',
					'fi' => 'Suomeksi',
					'es' => 'Español',
					'fr' => 'Français',
					'it' => 'Italiano',
					'nl' => 'Nederlands',
					'lb' => 'Luxembourgish', 
					'cs' => 'Czech',
					'sl' => 'Slovenščina', // Slovensk
					'lt' => 'Lietuvių kalba', // Lithuanian
					'hr' => 'Hrvatski', // Croatian
					'hu' => 'Magyar', // Hungarian
					'pl' => 'Język polski', // Polish
					'pt' => 'Português', // Portuguese
					'pt-BR' => 'Português brasileiro', // Portuguese
					'tr' => 'Türkçe',
					'el' => 'ελληνικά',
					'ja' => '日本語',
			);
		} else {
			$langnames = array(
				'no' => 'Bokmål',
				'nn' => 'Nynorsk',
				'se' => 'Sámi',
				'da' => 'Dansk',
				'en' => 'English',
				'de' => 'Deutsch',
				'sv' => 'Svenska',
				'fi' => 'Suomeksi',
				'es' => 'Español',
				'eu' => 'Euskara',
				'fr' => 'Français',
				'nl' => 'Nederlands',
				'lb' => 'Luxembourgish', 
				'cs' => 'Czech',
				'sl' => 'Slovenščina', // Slovensk
				'hr' => 'Hrvatski', // Croatian
				'hu' => 'Magyar', // Hungarian
				'pl' => 'Język polski', // Polish
				'pt' => 'Português', // Portuguese
				'pt-BR' => 'Português brasileiro', // Portuguese
				'tr' => 'Türkçe',
			);
		}
		
		$textarray = array();
		foreach ($languages AS $lang => $current) {
			if ($current) {
				$textarray[] = $langnames[$lang];
			} else {
				$textarray[] = '<a href="' . htmlspecialchars(SimpleSAML_Utilities::addURLparameter(SimpleSAML_Utilities::selfURL(), array('language' => $lang))) . '">' .
					$langnames[$lang] . '</a>';
			}
		}
		echo join(' | ', $textarray);
		echo '</div>';

	}



	?>
	<div id="content">



<?php

if(!empty($this->data['htmlinject']['htmlContentPre'])) {
	foreach($this->data['htmlinject']['htmlContentPre'] AS $c) {
		echo $c;
	}
}
